# etl-linkedin-offers

ETL para realizar/desarrollar ofertas de trabajo con Linkedin
